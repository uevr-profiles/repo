local CamPlayer = StaticFindObject("")
local ColorAndOpacity = { 1, 2, 3, 4 }
local AimCameraOffset = { 1, 2, 3 }



RegisterHook("/Script/Engine.PlayerController:ClientRestart", function(Context)
    ExecuteInGameThread(function()
	local aim_manager = StaticFindObject("/Game/ShooterGunSys/Blueprints/Widgets/HUD/CrosshairHud.CrosshairHud_C:WidgetTree.RevolverCrosshair")
    local func = aim_manager.GetItems
    print(tostring(aim_manager:type()))
    print(tostring(aim_manager:GetFullName()))
	print(tostring(func))
	aim_manager:SetPropertyValue("ColorAndOpacity", {
                ["R"] = 1,
                ["G"] = 1,
                ["B"] = 1,
				["A"] = 0,
            })
	print("ColorAndOpacity changed to R=1.000000, G=1.000000, B=1.000000, A=0.000000")
    end)
	

end)