local CamPlayer = StaticFindObject("")
local RelativeLocation = { 1, 2, 3 }


RegisterHook("/Script/Engine.PlayerController:ClientRestart", function(Context)
    ExecuteInGameThread(function()
    local item_manager = StaticFindObject("/Game/ShooterGunSys/Blueprints/Guns/SoulslingerGuns/SoulRevolver.SoulRevolver_C:ShotLoc_GEN_VARIABLE")
    local func = item_manager.GetItems
    print(tostring(item_manager:type()))
    print(tostring(item_manager:GetFullName()))
	print(tostring(func))
	item_manager:SetPropertyValue("RelativeLocation", {
                ["X"] = 0,
                ["Y"] = -15,
                ["Z"] = 30,
            })
	print("Socket Offset changed to X=0.000000, Y=-15.000000, Z=30.000000")
    end)
	

end)