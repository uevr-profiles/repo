local LuaVR = require("LuaVR")
Runonce = false
local hasrun = false
TalkingS = false
TalkingF = true
ZipHooked = false
PortalHooked = false
InvHooked = false
TalkHooked = false
IntroP = false

local params = LuaVR.params
local callbacks = params.sdk.callbacks
local api = LuaVR.api

function FTCam()
print("Waiting to apply Camera Mod")
	local ActorInstance = FindFirstOf("BP_ActSceneManager_C")
    if not ActorInstance then
		print("Camera not active yet ...\n")
	else
        --print(tostring(ActorInstance:GetFullName()))
        local setscene = ActorInstance:GetFullName():sub(22)
        --print(setscene)
        local scene_manager = StaticFindObject(setscene)
		local iscene = tostring(scene_manager.InteractiveScene)
        if string.find(iscene, "AActor") then
            TalkingS = true
            --print("Dialogue Detected")
            --print("Is Talking : " .. iscene)
            --print("Is Talking : " .. iscene)
        else
            --print("Is NOT Talking : " .. iscene)
        end
	end
end

function CheckActorFirst()
    local ActorInstance = FindFirstOf("BP_ActSceneManager_C")
    if not ActorInstance then
		print("Camera not active yet ...\n")
	else
		local actor = tostring(ActorInstance.InteractiveScene)
        if string.find(actor, "AActor") then
            if StillTalkingS == true then
            else
                --print("Is Talking : " .. actor)
                StillTalkingS = true
                TalkingS = true
                TalkingF = false
                params.vr.set_aim_method(0)
                --print("Is Talking : " .. iscene)
            end
        else
            if StillTalkingS == false then
            else
            --print("Dialogue Ended")
            StillTalkingS = false
            TalkingS = false
            TalkingF = true
            params.vr.set_aim_method(2)
            end
        end
	end
end

function FPCam()
    local HeadInstances = FindAllOf("ABP_StoryCharacter_C")
        if not HeadInstances then
            else
                for Index, HeadInstances in pairs(HeadInstances) do
                    for matchedText in string.gmatch(HeadInstances:GetFullName(), ".CharacterMesh0.ABP_StoryCharacter_C_") do
                        GetHead = HeadInstances:GetFullName():sub(22)
                        local istalking = StaticFindObject(GetHead)
                        --print(GetHead)
                        --local ins_manager = StaticFindObject(istalking)
                        local conv = tostring(istalking['Is Talking'])
                        local list = tostring(istalking['Is Listening'])
                        --print("Is Talking : " .. conv)
                        --print("Is Listening : " .. list)
                        if conv == "true" or list == "true" then
                            TalkingS = true
                            TalkingF = false
                            --print("Dialogue Detected")
                        end
                    end
                end
        end
end

function CheckTalk()
if TalkHooked == false then
	TalkHooked = true
    --local TalkInstances = StaticFindObject("GetHead")
    RegisterHook("/Game/0Game/Blueprints/Animation/ABP_StoryCharacter.ABP_StoryCharacter_C:Set Talk to Current Slot", function (Context, Style)
        if TalkingS == false then
            local ActorInstance = FindFirstOf("BP_ActSceneManager_C")
            if not ActorInstance then
                --print("Camera not active yet ...\n")
            else
                --print(tostring(ActorInstance:GetFullName()))
                local setscene = ActorInstance:GetFullName():sub(22)
                --print(setscene)
                local scene_manager = StaticFindObject(setscene)
                local iscene = tostring(scene_manager.InteractiveScene)
                if string.find(iscene, "AActor") then
                    TalkingS = true
                    TalkingF = false
                    StillTalkingS = true
                    params.vr.set_aim_method(0)
                    --print("Dialogue Detected")
                    --print("Is Talking : " .. iscene)
                end
            end
        end
    end)
    RegisterHook("/Script/ModernStoryteller01.ActSceneManager:OnSceneDestroyed", function (Context)
        ExecuteWithDelay(500,function()
        if TalkingF == false then
            CheckActorFirst()
        end
        end)
    end)
end	
end

params.vr.set_aim_method(0)
params.vr.recenter_view()

Runhook = false

LuaVR.sdk.callbacks.on_pre_engine_tick(function(engine, delta)
function HideBody()

if Runonce == false then 
    Runonce = true
	params.vr.set_aim_method(2)
    local skeletal_mesh_c = api:find_uobject("Class /Script/Engine.SkeletalMeshComponent")
    if skeletal_mesh_c == nil then print("skeletal_mesh_c is nil") end
    local skeletal_meshes = skeletal_mesh_c:get_objects_matching(false)

    local arms_mesh = nil
    for i, mesh in ipairs(skeletal_meshes) do
        if mesh:get_fname():to_string() == "CharacterMesh0" and string.find(mesh:get_full_name(), "BP_PlayerCharacter_C") then
            Fpmesh = mesh
            --print(Fpmesh:get_full_name())
            Fpmesh:call("SetRenderInMainPass", false)

            break
        end
    end


local comp_c = api:find_uobject("Class /Script/Engine.StaticMeshComponent")

    if comp_c == nil then print("comp_c is nil") end
    
    local skeletal_meshes = comp_c:get_objects_matching(false)
    --local comp_inv = pawn:K2_GetComponentsByClass(comp_c)

    local c_cam = nil
    for i, cicam in ipairs(skeletal_meshes) do
        if cicam:get_fname():to_string() == "RightSleeve" then
            cheat_manager_m = cicam
            cheat_manager_m:call("SetRenderInMainPass", false)
			
            break
        end
    end
	
local comp_c = api:find_uobject("Class /Script/Engine.StaticMeshComponent")

    if comp_c == nil then print("comp_c is nil") end
    
    local skeletal_meshes = comp_c:get_objects_matching(false)
    --local comp_inv = pawn:K2_GetComponentsByClass(comp_c)

    local c_cam = nil
    for i, cicam in ipairs(skeletal_meshes) do
        if cicam:get_fname():to_string() == "LeftSleeve" then
            cheat_manager_m = cicam
            cheat_manager_m:call("SetRenderInMainPass", false)
			
            break
        end
    end	


end
end


end)


function MenuDetect()
	local ins_manager = StaticFindObject("/Game/0Game/UI/Splash_LegalLogos.Splash_LegalLogos_C:On Logos Finished")
    if ins_manager:IsValid() then
	RegisterHook("/Game/0Game/UI/Splash_LegalLogos.Splash_LegalLogos_C:OnInitialized", function (Context)
        params.vr.set_aim_method(0)
		params.vr.recenter_view()
		--params.vr.recenter_horizon()
        --print("Menu Detected")
	end)
	RegisterHook("/Game/0Game/UI/Splash_LegalLogos.Splash_LegalLogos_C:On Logos Finished", function (Context)
        params.vr.set_aim_method(0)
		params.vr.recenter_view()
		--params.vr.recenter_horizon()
        --print("Menu Detected")
	end)
    end
	local ins_manager = StaticFindObject("/Game/0Game/Levels/MainMenu.MainMenu_C:ReceiveBeginPlay")
    if ins_manager:IsValid() then
    RegisterHook("/Game/0Game/Levels/MainMenu.MainMenu_C:ReceiveBeginPlay", function (Context)
        params.vr.set_aim_method(0)
		params.vr.recenter_view()
		--params.vr.recenter_horizon()
        --print("Menu Detected")
    end)
	end
	local ins_manager = StaticFindObject("/Game/0Game/Levels/MainMenu.MainMenu_C:ReceiveEndPlay")
    if ins_manager:IsValid() then
    RegisterHook("/Game/0Game/Levels/MainMenu.MainMenu_C:ReceiveEndPlay", function (Context)
		Runonce = false
		Runhook = false
		HideBody()
		params.vr.set_aim_method(0)
        --print("Menu Ended")
    end)
	
	end

end

function ZipDetect()
if ZipHooked == false then
	local ins_manager = StaticFindObject("/Game/0Game/Blueprints/Actors/BP_ZipLineRider.BP_ZipLineRider_C:Begin Ride V2")
    if ins_manager:IsValid() then
	ZipHooked = true

    RegisterHook("/Game/0Game/Blueprints/Actors/BP_ZipLineRider.BP_ZipLineRider_C:Begin Ride V2", function (Context)
        params.vr.set_aim_method(0)
		params.vr.recenter_view()
        --print("ZipLine Detected")
    end)
    RegisterHook("/Game/0Game/Blueprints/Actors/BP_PlayerCharacter.BP_PlayerCharacter_C:On Hit Zipline End", function (Context)
        params.vr.set_aim_method(2)
        --print("ZipLine Ended")
    end)
	else
		ZipHooked = false
	end
end	
end

function PortalDetect()
if PortalHooked == false then
	PortalHooked = true
	local ins_manager = StaticFindObject("/Game/0Game/Meshes/Wormhole/BP_SplineWormhole_Loop.BP_SplineWormhole_Loop_C:BndEvt__Player_HitTimePortal_K2Node_ComponentBoundEvent_0_GameEventDelegate__DelegateSignature")
    if ins_manager:IsValid() then
    RegisterHook("/Game/0Game/Meshes/Wormhole/BP_SplineWormhole_Loop.BP_SplineWormhole_Loop_C:BndEvt__Player_HitTimePortal_K2Node_ComponentBoundEvent_0_GameEventDelegate__DelegateSignature", function (Context)
        params.vr.set_aim_method(0)
		params.vr.recenter_view()
        --print("Portal Detected")
    end)
    RegisterHook("/Game/0Game/Blueprints/Actors/Interactive_Misc/BP_TimelineSwitcher.BP_TimelineSwitcher_C:BndEvt__Player_AboutToExitPortal_K2Node_ComponentBoundEvent_6_GameEventDelegate__DelegateSignature", function (Context)
        params.vr.set_aim_method(2)
        --print("Portal Ended")
    end)
	end
end	
end

function InventoryDetect()
if InvHooked == false then
	InvHooked = true
    RegisterHook("/Game/0Game/UI/PlayerMenu_Examine.PlayerMenu_Examine_C:On Shown", function (Context)
		
        params.vr.set_aim_method(2)
        --print("Inventory Detected")
        local ExInstance = FindFirstOf("Examiner_C")
            if not ExInstance then
		        print("Camera not active yet ...\n")
	        else
                --print(tostring(ExInstance:GetFullName()))
                local setscene = ExInstance:GetFullName():sub(12)
                --print(setscene)
				
                local sm_convert = StaticFindObject(setscene):GetFullName()
				local get_scene = string.gsub(sm_convert, ":", ".")
				local scene_manager = api:find_uobject(get_scene)
				--print(tostring(scene_manager))
		        --Iscene = scene_manager.State
                CharSel = scene_manager["Examining Actor"]:get_full_name()
				--print(tostring(CharSel))
                if StillTalkingS == true then
					params.vr.set_aim_method(0)
					if string.find(CharSel, "Coin") then
						--print("Coin")
						scene_manager["Distance From Camera"] = 50.0
						scene_manager["Original Radius"] = 200.0
					elseif string.find(CharSel, "Ammo") then
						--print("Bulet")
						scene_manager["Distance From Camera"] = 50.0
						scene_manager["Original Radius"] = 150.0	
					else
						--print("Item Given")
						scene_manager["Distance From Camera"] = 90.0
						scene_manager["Original Radius"] = 20.0
					end
                else
					--print("Inventory")
                    scene_manager["Distance From Camera"] = 90.0
					scene_manager["Original Radius"] = 90.0
                end
	        end
    end)
    RegisterHook("/Game/0Game/UI/PlayerMenu_Examine.PlayerMenu_Examine_C:On Hidden", function (Context)
	if StillTalkingS == true then
		params.vr.set_aim_method(0)
	else	
        params.vr.set_aim_method(2)
	end	
        --print("Inventory Ended")
    end)
	
	
end	
end

function IntroDetect()

local ActorInstance = FindFirstOf("BP_ActSceneManager_C")
            if not ActorInstance then
                --print("Camera not active yet ...\n")
            else
			
				local setscene = ActorInstance:GetFullName():sub(22)
                --print(setscene)
				
                local sm_convert = StaticFindObject(setscene):GetFullName()
				local get_scene = string.gsub(sm_convert, ":", ".")
				local scene_manager = api:find_uobject(get_scene)
				--print(tostring(scene_manager))
		        --Iscene = scene_manager.State
                CharSel = scene_manager:get_property("DisplayedScene"):get_full_name()
				if CharSel == nil then
				print(tostring(CharSel))
				--[[
                --print(tostring(ActorInstance:GetFullName()))
                local setscene = ActorInstance:GetFullName():sub(22)
                --print(setscene)
                local scene_manager = StaticFindObject(setscene)
                local iscene = tostring(scene_manager.DisplayedScene)
				print(iscene)
				]]--
                
                    params.vr.set_aim_method(2)
					print("Aim 2")
                else
					params.vr.set_aim_method(0)
					print("Aim 0")
				end
            end

end

function ConvEnd()
    if IsFinished == true then
        --print("Dialogue Ended")
        TalkingS = false
        TalkingF = true
    end
end

function TalkCheck()
    local talkingS = false
    local talkingF = false
    --local TalkInstances = StaticFindObject("GetHead")
    RegisterHook("/Game/0Game/Blueprints/Animation/ABP_StoryCharacter.ABP_StoryCharacter_C:Set Talk to Current Slot", function (Context, Style)
        if talkingS == false then
            local isactive = FindFirstOf("ABP_StoryCharacter_C")
            local istalking = isactive:GetFullName():sub(22)
            --print(istalking)
            local ins_manager = StaticFindObject(istalking)
            local conv = tostring(ins_manager['Is Talking'])
            local list = tostring(ins_manager['Is Listening'])
            --print("Is Talking : " .. conv)
            --print("Is Listening : " .. list)
            if conv == true or list == true then
                --print("Dialogue Detected")
                --local currentstate = tostring(Style)
                --print(currentstate)
                talkingS = true
                talkingF = false
            end
        end
    end)
    RegisterHook("/Script/ModernStoryteller01.ActSceneManager:OnSceneDestroyed", function (Context)
        if talkingF == false then
        --print("Dialogue Ended")
        --local currentstate = tostring(Style)
        --print(currentstate)
        talkingS = false
        talkingF = true
        end
    end)
end

MenuDetect()

params.vr.set_aim_method(0)


RegisterHook("/Script/Engine.PlayerController:ClientRestart", function(Context)
    ExecuteInGameThread(function()
	if Runhook == false then
        CheckTalk()
		Runhook = true
        --HideBody()
		
        InventoryDetect()
		
		params.vr.set_aim_method(2)
		--ExecuteWithDelay(10000, IntroDetect)
		ExecuteWithDelay(10000, PortalDetect)
		ExecuteWithDelay(10000, ZipDetect)
		--print("Applied")

		--params.vr.set_aim_method(0)
		params.vr.recenter_view()
        --print("Menu Ended")

	end	
    end)
end)

