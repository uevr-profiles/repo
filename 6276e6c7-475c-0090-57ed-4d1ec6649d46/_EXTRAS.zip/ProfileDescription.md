## Installation and configuration
### DLSS Swapper
+ Use [DLSS Swapper](https://github.com/beeradmoore/dlss-swapper/releases) to update DLSS to 310.3.0 or higher (important, game it runs an outdated version)
### Profile inspector
Use [Nvidia Profile Inspector](https://github.com/Orbmu2k/nvidiaProfileInspector/releases) to set:
+ DSS forced preset letter to "...PRESET_K"
+ rBar Feature 1
+ rBar Options 0x1
+ rBar Size Limit 0x40000000
## In game graphic settings:
(You can set them lower, but not higher)
+ Foveated Scope LOW
+ Shadow Quality MEDIUM
+ Anti Aliasing LOW
+ Effect LOW
+ all the rest HIGH/ON
## Restrictions
+ Inject when already in 3D in the game (after launch, you can inject here in UEVR Easy)
## Description
On Meta Quest controllers, while pressing the left controllers sensitive area you can use the right controllers joystick to control e.g. lights
## Revision
Latest version takes scopes from Pande and vertical right joystick delivers keys U and D, using the plugin from gameflorist.
The game now also works with native rendering without the nasty shadow flickering.
