## Installation and configuration
Let the game load to space dock before injecting
## Description
Turn off crosshairs but UI is fixed to view and 6DOF for gun. May require tweaks on the hooked object to get your aim to your liking. Synced sequential to keep double outlines when using the scanner.