#include <Array.au3>
#include <File.au3>
#include <MsgBoxConstants.au3>
#include <misc.au3>
#include <WinAPIProc.au3>

_Singleton("ff7r", 0)


Local $ToRun = "";
If $CmdLine[0] >= 1 Then
    $ToRun = '"' & $CmdLine[1] & '"';
    For $i=2 to $CmdLine[0] Step 1
        $ToRun = $ToRun & " " & $CmdLine[$i];
    Next
    
    $ToRun = $ToRun & " -dx11";
EndIf

Run(@scriptdir & "\3dmigotoloader\3DMigoto Loader.exe", @scriptdir & "\3dmigotoloader\");
Sleep(500);
Run($ToRun);
