Works only in DirectX11. Enable dx11 with the launch parameter -dx11  
Set Windowed Mode in game. Important to trigger VR with UEVR correctly.

0. Extract the Loader Mod to a place which is NOT in the game folder
1. Run Loader (3DMigoto Loader.exe)
2. Run Game (FF7)
3. Inject Game (FF7) with UEVR later

Press F5 to toggle HUD in game.
Press F4 to toggle Vignette in game.

This loader mod disables pesky visual effects in Native Stereo or Synced Sequential.
Its aim is to enhance the game experience in VR.

The following effects are disabled:

- Vignette
- Blur
- Chromatic Aberration
- Ghosting in Chapter 2 of the Game if applicable
- Cutscene Effects