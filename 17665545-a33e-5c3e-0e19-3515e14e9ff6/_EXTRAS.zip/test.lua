print("hello world") --testing the exicutable
print(uevr.api:get_local_pawn(0):get_full_name())
print(uevr.api:get_local_pawn(0))