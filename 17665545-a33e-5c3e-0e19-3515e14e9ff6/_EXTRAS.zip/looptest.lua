local params = LuaVR.params					--these two lines are needed
local callbacks = params.sdk.callbacks		--for the call back i think?


vartest = "hi"
loopCount = 0

print(vartest)

callbacks.on_pre_engine_tick(function(engine, delta)
	print("loopCount")
	loopCount = loopCount+1

end)

