( See markdownguide.org for help with Markdown format )
## Installation and configuration
( run in minimal resolution, DLSS performance setting )
## Restrictions
( very graphically intensive, may require reducing graphics quality - high worked well with my RTX 5070 Ti )
## Description
( Gorgeous game to play! )