## Installation and configuration

Profile installation as usual. Start game flat first. Settings: bordeless window, unlimited fps, vsync off, low-medium settings unless you got a high-end gpu.

## Restrictions

Start/Pause menu unusable. Start game, then inject or tab out of vr mode with virtual desktop to hit "New Game" or get into settings.

## Description

OpenXR, Native Stereo, 6DOF motion controls, removed bodycam- and crt screen- filters  
Game-inputsettings are buggy, but UEVR default mapping for quest 3 controllers is ok.

