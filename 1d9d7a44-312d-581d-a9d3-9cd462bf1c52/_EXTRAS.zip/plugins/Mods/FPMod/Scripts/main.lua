local appdata = os.getenv('APPDATA')
VRAim = "VR"
First = true
Third = false
local scanstarted = false
local stopscan = false
Scanning = false
ER = false
TL = false
CS = false
CL = false

function InitiatePlaycheck()
	if VRAim == "Game"
	then
		SetGameInput()
	elseif VRAim == "VR"
	then
		SetVRInput()
	end
end

function Get_lines(filename)
    configfile = appdata .."\\UnrealVRMod\\Project-Win64-Shipping\\config.txt"
	file = io.open(configfile, "r")
	io.input(file)
    local lines = {}
    -- io.lines returns an iterator, so we need to manually unpack it into an array
    for line in io.lines(filename) do
        lines[#lines+1] = line
		local findText = string.match(line, "VR_AimMethod")
        --print(findText)
		local toprint = io.read()
        --print(toprint)
		if toprint == "VR_AimMethod=0"
		then
			VRAim = "Game"
			print(toprint .. " : Game Aiming Detected")
		elseif toprint == "VR_AimMethod=1"
		then
			VRAim = "Game"
			print(toprint .. " : Head Aiming Detected")
		elseif toprint == "VR_AimMethod=2"
		then
			VRAim = "VR"
			print(toprint .. " : RIGHT 3DOF or 6DOF Aiming Detected")
		elseif toprint == "VR_AimMethod=3"
		then
			VRAim = "VR"
			print(toprint .. " : LEFT 3DOF or 6DOF Aiming Detected")
		end
    end
    return lines
end
--Get_lines(filename)

function Init()
    CamPlayer = FindFirstOf("BP_PlayerCharacter_MH_C")
    if not CamPlayer:IsValid()
    then
        error("Camera Not Found Yet ...\n")
    else
        IsInitialized = true
        local view_manager = FindFirstOf("BP_PlayerCharacter_MH_C")
        view_manager.bFindCameraComponentWhenViewTarget = false
        --view_manager.bUseControllerRotationYaw = true
        AdjustCam()
        HideHead()
        AutoScan()
        ScanCancel()
        ExecuteWithDelay(10000, CalibrateEndFunction)
		print("Camera Mod Applied Successfully ...\n")
    end
end

function TPT()
    if First == true then
        local view_manager = FindFirstOf("BP_PlayerCharacter_MH_C")
        ThirdShow()
        view_manager.bFindCameraComponentWhenViewTarget = true
        First = false
        Third = true
    else
        local view_manager = FindFirstOf("BP_PlayerCharacter_MH_C")
        ThirdHide()
        view_manager.bFindCameraComponentWhenViewTarget = false
        First = true
        Third = false
    end
end

function AutoScan()
    if scanstarted == false
        then
            RegisterHook("/Game/MetaHumans/Kate/AnimPrototype/BP_PlayerCharacter_MH.BP_PlayerCharacter_MH_C:FX_PulseScan", function (context, bSuccess)
                --mfdstring = tostring(bSuccess:get())
                --print("Scan Success : " .. mfdstring)
                scansuccess = bSuccess:get()
                if scansuccess == true then
                ScanCamStart()
                end
            end)
            RegisterHook("/Game/MetaHumans/Kate/AnimPrototype/BP_PlayerCharacter_MH.BP_PlayerCharacter_MH_C:VFX_PulseScan_Anim__FinishedFunc", function (context)
                ExecuteWithDelay(1000, ScanCamEnd)
            end)
            scanstarted = true
    end
end

function ScanCamStart()
    if Scanning == false then
        Scanning = true
        local ScanInstances = FindAllOf("ScarsPlayerSpringArmComponent")
        if not ScanInstances then
            print("Character not active yet ...\n")
        else
        for Index, ScanInstances in pairs(ScanInstances) do
            for matchedText in string.gmatch(ScanInstances:GetFullName(), "PersistentLevel.BP_PlayerCharacter_MH_C") do
                GetHead = ScanInstances:GetFullName()
                local rid = (GetHead:match "%d+")
                RandomID = rid
                if #rid < 10 then
                else
                    local cam_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Spring Arm")
                    cam_manager.DesiredCameraSetup.TargetArmLength = 0
                    cam_manager.DesiredCameraSetup.SocketOffset = {X=-0, Y=0, Z=4}
                    local view_manager = FindFirstOf("BP_PlayerCharacter_MH_C")
                    view_manager.bFindCameraComponentWhenViewTarget = true
                end
            end
        end
        end
    end
end

function ScanCamEnd()
    if Scanning == true then
        local ScanInstances = FindAllOf("ScarsPlayerSpringArmComponent")
        if not ScanInstances then
            print("Character not active yet ...\n")
        else
        for Index, ScanInstances in pairs(ScanInstances) do
            for matchedText in string.gmatch(ScanInstances:GetFullName(), "PersistentLevel.BP_PlayerCharacter_MH_C") do
                GetHead = ScanInstances:GetFullName()
                local rid = (GetHead:match "%d+")
                RandomID = rid
                if #rid < 10 then
                else
                    local cam_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Spring Arm")
                    cam_manager.DesiredCameraSetup.TargetArmLength = 300
                    cam_manager.DesiredCameraSetup.SocketOffset = {X=150, Y=55, Z=-9}
                    local view_manager = FindFirstOf("BP_PlayerCharacter_MH_C")
                    view_manager.bFindCameraComponentWhenViewTarget = false
                end
            end
        end
        end
        Scanning = false
        ER = false
        TL = false
        CS = false
        CL = false
    end
end

function ScanCancel()
    if stopscan == false then
        RegisterHook("/Game/_UI/Crosshair/W_Crosshair_EnergyRailPrototype.W_Crosshair_EnergyRailPrototype_C:UpdateCrosshairAimingTransition", function (context)
            if ER == false and Scanning == true then
                ScanCamEnd()
            end
        end)
        RegisterHook("/Game/_UI/Crosshair/W_Crosshair_ThermiteLauncherPrototype.W_Crosshair_ThermiteLauncherPrototype_C:UpdateCrosshairAimingTransition", function (context)
            if TL == false and Scanning == true then
                ScanCamEnd()
            end
        end)
        RegisterHook("/Game/_UI/Crosshair/W_Crosshair_ChemicalShotgunPrototype.W_Crosshair_ChemicalShotgunPrototype_C:UpdateCrosshairAimingTransition", function (context)
            if CS == false and Scanning == true then
                ScanCamEnd()
            end
        end)
        RegisterHook("/Game/_UI/Crosshair/W_Crosshair_CryoLauncher.W_Crosshair_CryoLauncher_C:UpdateCrosshairAimingTransition", function (context)
            if CL == false and Scanning == true then
                ScanCamEnd()
            end
        end)
        stopscan = true
    end
end

function ThirdShow()
    local HeadInstances = FindAllOf("SkeletalMeshComponent")
    if not HeadInstances then
        print("Character not active yet ...\n")
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), "Face") do
            GetHead = HeadInstances:GetFullName()
            if string.find(GetHead,"PlayerCharacter_MH_C")
            then
                local rid = (GetHead:match "%d+")
            if #rid < 10 then
            else
                local head_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Face")
                head_manager.bVisible = true
                local hair_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".SK_KateHair")
                hair_manager.bVisible = true
                if VRAim == "VR"
		        then
                    local Body_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Bag")
                    Body_manager.bVisible = true
                    local Leg_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Legs")
                    Leg_manager.bVisible = true
                    local Armor_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Torso")
                    Armor_manager.bVisible = true
                    local Backpack_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".SK_KateShield")
                    Backpack_manager.bVisible = true
                    local mesh_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".CharacterMesh0")
                    mesh_manager.bVisible = true
                    local Hide_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid)
                    Hide_manager.bHidden = true
                end
            end
        end
        end
    end
    end
end

function ThirdHide()
    local HeadInstances = FindAllOf("SkeletalMeshComponent")
    if not HeadInstances then
        print("Character not active yet ...\n")
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), "Face") do
            GetHead = HeadInstances:GetFullName()
            if string.find(GetHead,"PlayerCharacter_MH_C")
            then
                local rid = (GetHead:match "%d+")
                if #rid < 10 then
                else
                    local head_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Face")
                    head_manager.bVisible = false
                    local hair_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".SK_KateHair")
                    hair_manager.bVisible = false
                    if VRAim == "VR"
		            then
			            local Body_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Bag")
			            Body_manager.bVisible = false
			            local Leg_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Legs")
			            Leg_manager.bVisible = false
			            local Armor_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Torso")
			            Armor_manager.bVisible = false
			            local Backpack_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".SK_KateShield")
			            Backpack_manager.bVisible = false
                        local mesh_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".CharacterMesh0")
			            mesh_manager.bVisible = false
                        local Hide_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid)
			            Hide_manager.bHidden = true
                    end
                end
            end
        end
    end
    end
end

function CraftCheck()
	print("Crafting Detection Enabled")
	local acut_not_hooked = true
    local craftstarted = false
	NotifyOnNewObject("/Script/Engine.PlayerController", function (Component)
	if acut_not_hooked then
        RegisterHook("/Script/Project.InteractionPayloadFSM:OnStateEntered", function (InContext)
            local HeadInstances = FindAllOf("InteractionComponent")
            if not HeadInstances then
                print("InteractionComponent not active yet ...\n")
            else
            for Index, HeadInstances in pairs(HeadInstances) do
                for matchedText in string.gmatch(HeadInstances:GetFullName(), "PersistentLevel.BP_CraftingTable") do
                    GetHead = HeadInstances:GetFullName():sub(22)
                    local ins_manager = StaticFindObject(GetHead)
                    local interaction = ins_manager.bInteractionEnabled
                    if interaction == true
                    then
                        craftstarted = true
                        CraftHide()
                    end
                end
            end
            end
        end)
	    RegisterHook("/Script/Project.FSMPayload:OnStateExited", function (self, InContext)
            if craftstarted == true
            then
                ExecuteWithDelay(2000, CraftEnd)
		        craftstarted = false
            end
	    end)
	    acut_not_hooked = false
	end
	end)
end

function CalibrateEndFunction()
    local levelcheck = StaticFindObject("/Game/_UI/ExamineScreen/Vera/W_VeraLaptopScreen_ModulationPuzzle.W_VeraLaptopScreen_ModulationPuzzle_C")
    if levelcheck:IsValid() then
    RegisterHook("/Game/_UI/ExamineScreen/Vera/W_VeraLaptopScreen_ModulationPuzzle.W_VeraLaptopScreen_ModulationPuzzle_C:Stop", function (self)
        CTool()
	end)
    end
end

function CraftHide()
    if First == true then
    local HeadInstances = FindAllOf("SkeletalMeshComponent")
    if not HeadInstances then
        print("Character not active yet ...\n")
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), "Face") do
            GetHead = HeadInstances:GetFullName()
            if string.find(GetHead,"PlayerCharacter_MH_C")
            then
                local rid = (GetHead:match "%d+")
                if #rid < 10 then
                else
                    HideWeapons()
                    if VRAim == "VR"
		            then
                    else
                        local head_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Face")
                        head_manager.bVisible = false
                        local hair_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".SK_KateHair")
                        hair_manager.bVisible = false
			            local Body_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Bag")
			            Body_manager.bVisible = false
			            local Leg_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Legs")
			            Leg_manager.bVisible = false
			            local Armor_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Torso")
			            Armor_manager.bVisible = false
			            local Backpack_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".SK_KateShield")
			            Backpack_manager.bVisible = false
                        local mesh_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".CharacterMesh0")
			            mesh_manager.bVisible = false
                        local Hide_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid)
			            Hide_manager.bHidden = true
                    end
                end
            end
        end
    end
    end
    end
end

function CraftEnd()
    if First == true then
    local HeadInstances = FindAllOf("SkeletalMeshComponent")
    if not HeadInstances then
        print("Character not active yet ...\n")
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), "Face") do
            GetHead = HeadInstances:GetFullName()
            if string.find(GetHead,"PlayerCharacter_MH_C")
            then
                local rid = (GetHead:match "%d+")
            if #rid < 10 then
            else
                ShowWeapons()
                if VRAim == "VR"
		        then
                else
                    local Body_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Bag")
                    Body_manager.bVisible = true
                    local Leg_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Legs")
                    Leg_manager.bVisible = true
                    local Armor_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Torso")
                    Armor_manager.bVisible = true
                    local Backpack_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".SK_KateShield")
                    Backpack_manager.bVisible = true
                    local mesh_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".CharacterMesh0")
                    mesh_manager.bVisible = true
                    local Hide_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid)
                    Hide_manager.bHidden = true
                end
            end
        end
        end
    end
    end
    end
end

function HideWeapons()
    if First == true then
    local HeadInstances = FindAllOf("SkeletalMeshComponent")
    if not HeadInstances then
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), ".ModMesh") do
            GetHead = HeadInstances:GetFullName():sub(23)
            local ins_manager = StaticFindObject(GetHead)
            ins_manager.bVisible = false
        end
    end
    end
    local HeadInstances = FindAllOf("SkeletalMeshComponent")
    if not HeadInstances then
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), ".WeaponMesh") do
            GetHead = HeadInstances:GetFullName():sub(23)
            local ins_manager = StaticFindObject(GetHead)
            ins_manager.bVisible = false
        end
    end
    end
    local HeadInstances = FindAllOf("SkeletalMeshComponent")
    if not HeadInstances then
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), ".SK_CombatKnife") do
            GetHead = HeadInstances:GetFullName():sub(23)
            local ins_manager = StaticFindObject(GetHead)
            ins_manager.bVisible = false
        end
    end
    end
    local HeadInstances = FindAllOf("StaticMeshComponent")
    if not HeadInstances then
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), ".SM_Knife_Sheath") do
            GetHead = HeadInstances:GetFullName():sub(21)
            local ins_manager = StaticFindObject(GetHead)
            ins_manager.bVisible = false
        end
    end
    end
    local HeadInstances = FindAllOf("ParticleSystemComponent")
    if not HeadInstances then
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), ".P_EnergyRail_Idle") do
            GetHead = HeadInstances:GetFullName():sub(25)
            local ins_manager = StaticFindObject(GetHead)
            ins_manager.bVisible = false
        end
    end
    end
    --Must Be Last
    local HeadInstances = FindAllOf("BP_EnergyRail_C")
    if not HeadInstances then
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), "/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_EnergyRail_C_") do
            GetHead = HeadInstances:GetFullName():sub(17)
            local ins_manager = StaticFindObject(GetHead)
            ins_manager.bHidden = true
        end
    end
    end
    end
end

function ShowWeapons()
    if First == true then
    local HeadInstances = FindAllOf("SkeletalMeshComponent")
    if not HeadInstances then
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), ".ModMesh") do
            GetHead = HeadInstances:GetFullName():sub(23)
            local ins_manager = StaticFindObject(GetHead)
            ins_manager.bVisible = true
        end
    end
    end
    local HeadInstances = FindAllOf("SkeletalMeshComponent")
    if not HeadInstances then
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), ".WeaponMesh") do
            GetHead = HeadInstances:GetFullName():sub(23)
            local ins_manager = StaticFindObject(GetHead)
            ins_manager.bVisible = true
        end
    end
    end
    local HeadInstances = FindAllOf("SkeletalMeshComponent")
    if not HeadInstances then
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), ".SK_CombatKnife") do
            GetHead = HeadInstances:GetFullName():sub(23)
            local ins_manager = StaticFindObject(GetHead)
            ins_manager.bVisible = true
        end
    end
    end
    local HeadInstances = FindAllOf("StaticMeshComponent")
    if not HeadInstances then
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), ".SM_Knife_Sheath") do
            GetHead = HeadInstances:GetFullName():sub(21)
            local ins_manager = StaticFindObject(GetHead)
            ins_manager.bVisible = true
        end
    end
    end
    local HeadInstances = FindAllOf("ParticleSystemComponent")
    if not HeadInstances then
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), ".P_EnergyRail_Idle") do
            GetHead = HeadInstances:GetFullName():sub(25)
            local ins_manager = StaticFindObject(GetHead)
            ins_manager.bVisible = true
        end
    end
    end
    --Must Be Last
    local HeadInstances = FindAllOf("BP_EnergyRail_C")
    if not HeadInstances then
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), "/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_EnergyRail_C_") do
            GetHead = HeadInstances:GetFullName():sub(17)
            local ins_manager = StaticFindObject(GetHead)
            ins_manager.bHidden = true
        end
    end
    end
    end
end

function AdjustCam()
    local HeadInstances = FindAllOf("SkeletalMeshComponent")
    if not HeadInstances then
        print("Character not active yet ...\n")
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), "BP_PlayerCharacter_MH_C") do
            GetHead = HeadInstances:GetFullName()
            local rid = (GetHead:match "%d+")
            RandomID = rid
            if #rid < 10 then
            else
                local cam_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".CharacterMesh0")
                cam_manager.RelativeLocation = {X=-34, Y=0, Z=-77}
            end
        end
    end
    end
end

function HideHead()
    local HeadInstances = FindAllOf("SkeletalMeshComponent")
        if not HeadInstances then
            print("Character not active yet ...\n")
        else
        for Index, HeadInstances in pairs(HeadInstances) do
            for matchedText in string.gmatch(HeadInstances:GetFullName(), "Face") do
                GetHead = HeadInstances:GetFullName()
                if string.find(GetHead,"PlayerCharacter_MH_C")
                then
                    local rid = (GetHead:match "%d+")
                if #rid < 10 then
                else
                    local head_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Face")
                    head_manager.bVisible = false
                    local hair_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".SK_KateHair")
                    hair_manager.bVisible = false
                if VRAim == "VR"
			    then
				    local Body_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Bag")
				    Body_manager.bVisible = false
				    local Leg_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Legs")
				    Leg_manager.bVisible = false
				    local Armor_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Torso")
				    Armor_manager.bVisible = false
				    local Backpack_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".SK_KateShield")
				    Backpack_manager.bVisible = false
                    --local mesh_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".CharacterMesh0")
			        --mesh_manager.bVisible = false
			    end
                end
            end
            end
        end
    end
end

function ShowHead()
    local HeadInstances = FindAllOf("SkeletalMeshComponent")
    if not HeadInstances then
        print("Character not active yet ...\n")
    else
    for Index, HeadInstances in pairs(HeadInstances) do
        for matchedText in string.gmatch(HeadInstances:GetFullName(), "Face") do
            GetHead = HeadInstances:GetFullName()
            if string.find(GetHead,"PlayerCharacter_MH_C")
                then
                    local rid = (GetHead:match "%d+")
                if #rid < 10 then
                else
                    local head_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Face")
                    head_manager.bVisible = true
                    local hair_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".SK_KateHair")
                    hair_manager.bVisible = true
                if VRAim == "VR"
			    then
                    local Body_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Bag")
                    Body_manager.bVisible = true
                    local Leg_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Legs")
                    Leg_manager.bVisible = true
                    local Armor_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".Torso")
                    Armor_manager.bVisible = true
                    local Backpack_manager = StaticFindObject("/Game/Maps/World/MAP_World.MAP_World:PersistentLevel.BP_PlayerCharacter_MH_C_".. rid ..".SK_KateShield")
                    Backpack_manager.bVisible = true
			    end
                end
            end
            end
        end
    end
end

function CTool()
    local tool_manager = StaticFindObject("/Game/Maps/World/Intro_Hermes/SUB_Intro_Hermes_Gameplay.SUB_Intro_Hermes_Gameplay:PersistentLevel.BP_Examination_Vera_2.SpringArm")
    tool_manager.TargetArmLength = 25
    tool_manager.SocketOffset = {X=-10, Y=0, Z=-15}
end

RegisterHook("/Script/Engine.PlayerController:ClientRestart", function(Context)
    ExecuteInGameThread(function()
	Init()
    end)
end)

ExecuteWithDelay(3000, CraftCheck)
