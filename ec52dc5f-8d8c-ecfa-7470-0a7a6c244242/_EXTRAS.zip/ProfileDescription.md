## Description
- Increased World Scale slightly
- Resized UI/Menu for better functionality
- Included cvar list for better, sharper AA, plus a few optimizations