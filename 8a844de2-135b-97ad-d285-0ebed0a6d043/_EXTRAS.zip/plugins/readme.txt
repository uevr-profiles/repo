This is an xinput based control remapper for UEVR written as a per-game plugin. 
To install, copy into the plugins directory of your game. If the plugins folder doesn't
exist, create it. UEVR folder for the games can be found by clicking "open global dir"
on the UEVR main window then clicking into the specific game folder.


############ The rightkeypresses.dll binds right thumb pad + A, B, R3 respectively to F1, F2, and ENTER. ############


############ RemapControls.txt ############
The remapcontrols.dll is configured by a required remapcontrols.txt file. The format
of this text file is:
 
 lines starting with # are ignored.

 Each control uses the numbers as listed below. Buttons not assigned
 are left at default values.

	DISABLE_INPUT=0
	DPAD_UP=1
	DPAD_DOWN=2
	DPAD_LEFT=3
	DPAD_RIGHT=4
	START=5
	BACK=6
	L3=7
	R3=8
	LB=9
	RB=10
	A=11
	B=12
	X=13
	Y=14
	LSTICK_UP=15
	LSTICK_DOWN=16
	LSTICK_LEFT=17
	LSTICK_RIGHT=18
	RSTICK_UP=19
	RSTICK_DOWN=20
	RSTICK_LEFT=21
	RSTICK_RIGHT=22
	LT=23
	RT=24

 For example, to set swap A and X buttons use:
 A=13
 X=11

 To disable right analog up and down use:
 RSTICK_UP=0
 RSTICK_DOWN=0

 To have the right analog up and down press B and Y so you can 
 dodge while moving, for example, the left controller A and B 
 are mapped to xbox B and Y. So use:
 RSTICK_UP=14
 RSTICK_DOWN=12



 Shift buttons can be set up using SHIFT= command. Options are:
 0 - no shift
 1 - left thumb pad (occulus and openxr only)
 2 - right thumb pad (occulus and openxr only, DPAD is pre-set by UEVR
 3 - LB,RB,LT,RT all at once

 To set shift key to left thumb:
 SHIFT=1



 Shift action keys are set the same way as regular keys, but you
 use SHIFT_ in front of them. Also, they do nothing if the SHIFT=
 is not set.

 To set shifted right A to start, use:
 SHIFT_A=5



 This example will set the right stick up/down to use Y and B and
 allow for the default behavior to work if using left thumb pad shift

 RSTICK_UP=14
 RSTICK_DOWN=12
 SHIFT_A=5
 SHIFT_RSTICK_UP=19
 SHIFT_RSTICK_DOWN=20



 This example swaps left trigger and right grip

 LT=10
 RB=23



Here is a sample configuration for outer worlds.

############ Cut here #################

# Outer worlds configuration

# Set left trigger to RB, button 10
LT=10
# Set right button RB to 23, left trigger
RB=23
# Enable shift, mode 1 which is left quest 3 touch pad
SHIFT=1
# when shifting, set the right stick up to start button
SHIFT_RSTICK_UP=5
# when shifting, set the right stick down to back button.
SHIFT_RSTICK_DOWN=6
