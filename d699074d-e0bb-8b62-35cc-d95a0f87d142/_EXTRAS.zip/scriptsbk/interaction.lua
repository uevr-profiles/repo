local uevrUtils = require('libs/uevr_utils')
local interaction = require("libs/interaction")
local isDeveloperMode = false  
interaction.init(isDeveloperMode)
interaction.setInteractionType(interaction.InteractionType.Widget)
